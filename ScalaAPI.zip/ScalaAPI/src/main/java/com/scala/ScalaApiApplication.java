package com.scala;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScalaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScalaApiApplication.class, args);
	}

}
